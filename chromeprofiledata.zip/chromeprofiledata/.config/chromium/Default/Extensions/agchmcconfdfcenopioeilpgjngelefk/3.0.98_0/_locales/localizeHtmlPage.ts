/** Localizes HTML page content by replacing message placeholders with translated strings
 * from the appropriate locale file based on browser language.
 * 
 * Replaces strings with pattern __MSG_messageName__ with the corresponding 
 * translation from chrome.i18n.getMessage()
 */
const localizeHtmlPage = function() {
    // Log browser language for debugging
    console.debug("Browser UI language:", chrome.i18n.getUILanguage());
    
    // Helper function to replace message placeholders with translations
    const replaceMessagesInString = (text: string): string => {
        return text.replace(/__MSG_(\w+)__/g, (match: string, messageName: string) => {
            const translation = chrome.i18n.getMessage(messageName);
            return translation || match; // Keep original text if no translation found
        });
    };

    // Process all element attributes that may contain translation strings
    document.querySelectorAll("*").forEach((element: Element) => {
        Array.from(element.attributes).forEach(attr => {
            if (attr.value && attr.value.includes("__MSG_")) {
                attr.value = replaceMessagesInString(attr.value);
            }
        });
    });

    // Process text nodes using a TreeWalker (for better text node access)
    const treeWalker = document.createTreeWalker(
        document.body || document.documentElement,
        NodeFilter.SHOW_TEXT,
        {
            acceptNode: (node: Node) => {
                return node.nodeValue && node.nodeValue.includes("__MSG_") 
                    ? NodeFilter.FILTER_ACCEPT 
                    : NodeFilter.FILTER_SKIP;
            }
        } as NodeFilter
    );
    
    // Process each text node containing __MSG_ pattern
    let textNode: Text | null;
    while (textNode = treeWalker.nextNode() as Text | null) {
        if (textNode.nodeValue) {
            textNode.nodeValue = replaceMessagesInString(textNode.nodeValue);
        }
    }
}

export { localizeHtmlPage }